document.getElementById("Footer").innerHTML = "<footer class='text-light bg-dark'>Thanks for considering our establishment! Enjoy your stay here at the Kaliua Kove Bed & Breakfast!</footer>"
